<?php
include "../coomponts/LINK.php";
include "../Api/Sign.Api.php";
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Additional CSS styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
        }

        .container {
            margin-top: 50px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            font-weight: bold;
        }

        /* Customize the form controls */
        .form-control {
            border-radius: 15px; /* Rounded corners */
        }

        .btn-primary {
            padding: 10px 20px;
            background-color: #007bff;
            border: none;
            color: #fff;
            border-radius: 15px; /* Rounded corners for button */
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <div class="container mt-5 ">
        <form id="signupForm" class=" rounded-3 col-md-6 mx-auto shadow p-5 bs-blu">
            <div class="form-group">
                <label for="User_name">User Name</label>
                <input class="form-control rounded-pill" type="text" name="User_name" id="User_name" required>
            </div>
            <div class="form-group">
                <label for="Email">Email</label>
                <input class="form-control rounded-pill" type="email" name="Email" id="Email" required>
            </div>
            <div class="form-group">
                <label for="Mobile_number">Mobile Number</label>
                <input class="form-control rounded-pill" type="number" name="Mobile_number" id="Mobile_number" required>
            </div>
            <div class="form-group">
                <label for="Password">Password</label>
                <input class="form-control rounded-pill" type="password" name="Password" id="Password" required>
            </div>
            <button type="submit" class="btn btn-primary rounded-pill">Sign Up</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            $("#signupForm").submit(function(event) {
                console.log("Form Submitting");
                event.preventDefault();
                var username = $("#User_name").val();
                var email = $("#Email").val();
                var mobile_number = $("#Mobile_number").val();
                var password = $("#Password").val();

                $.ajax({
                    type: "POST",
                    url: "../Api/Sign.Api.php",
                    data: {
                        User_name: username,
                        Email: email,
                        Mobile_number: mobile_number,
                        Password: password
                    },
                    success: function(response) {
                        console.log(response);
                    }
                });
            });
        });
    </script>
</body>

</html>
