<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include "../../Connction/Dbconnction.php";
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["User_name"]);
    $password = mysqli_real_escape_string($conn, $_POST["Password"]);

    $sql = "SELECT * FROM admin WHERE user_name = '$username'";
    $result = $conn->query($sql);

    if (!$result) {
        echo "Error: " . $sql . "<br>" . $conn->error;
    } elseif ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $hashed_password = $row['PASSWORD'];

        if (password_verify($password, $hashed_password)) {
            $_SESSION["username"] = $username;
            echo "windowsh.Location.href='HOME.PHP'";
            exit(); // Ensure script execution stops after redirection
        } else {
            echo "Invalid username or password.";
        }
    } else {
        echo "Invalid username or password.";
    }
}

$conn->close();
?>
