<?php
include "../../Connction/Dbconnction.php";

// Set error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if form data is received
if (isset($_POST['User_name'], $_POST['Email'], $_POST['Mobile_number'], $_POST['Password'])) {

    // Assign form data to variables
    $username = $_POST['User_name'];
    $email = $_POST['Email'];
    $mobile_number = $_POST['Mobile_number'];
    $Password = $_POST['Password'];

    // Hash the password
    $Password_hashed = password_hash($Password, PASSWORD_DEFAULT);

    // Prepare SQL statement
    $sql = "INSERT INTO admin (user_name, email, moblie, PASSWORD) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    // Check for preparation errors
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters and execute statement
    $stmt->bind_param('ssss', $username, $email, $mobile_number, $Password_hashed);
    if ($stmt->execute()) {
        echo "New Record Added";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
    // Debugging statement to check form data
    var_dump($_POST);

    // Close statement
    $stmt->close();
} else {
    // echo "Form data is missing.";
}

// Close database connection
$conn->close();
