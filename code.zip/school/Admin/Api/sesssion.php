<?php
session_start();

// Check if user is logged in
if(!isset($_SESSION["username"])){
    header("Location: LOGIN.PHP"); // Redirect to login page if not logged in
    exit();
}

// Display welcome message
echo "Welcome, " . $_SESSION["username"] . "!";

// Logout button
echo '<form action="logout.php" method="post">
      <input type="submit" value="Logout">
      </form>';
?>
