<?php
$serever = "localhost";
$date_name = "root";
$date_Password = "";
$date_baes = "school";

$conn = new mysqli($serever , $date_name , $date_Password , $date_baes);

?>